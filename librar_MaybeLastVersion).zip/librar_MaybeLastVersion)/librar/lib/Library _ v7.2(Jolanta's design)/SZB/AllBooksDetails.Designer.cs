﻿namespace SZB
{
    partial class AllBooksDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AllBooksDetails));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iRBookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sZBDataSet11 = new SZB.SZBDataSet11();
            this.issuedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sZBDataSet6 = new SZB.SZBDataSet6();
            this.issuedTableAdapter = new SZB.SZBDataSet6TableAdapters.issuedTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sZBDataSet7 = new SZB.SZBDataSet7();
            this.returnedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.returnedTableAdapter = new SZB.SZBDataSet7TableAdapters.returnedTableAdapter();
            this.sZBDataSet8 = new SZB.SZBDataSet8();
            this.returnedBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.returnedTableAdapter1 = new SZB.SZBDataSet8TableAdapters.returnedTableAdapter();
            this.sZBDataSet9 = new SZB.SZBDataSet9();
            this.returnedBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.returnedTableAdapter2 = new SZB.SZBDataSet9TableAdapters.returnedTableAdapter();
            this.sZBDataSet10 = new SZB.SZBDataSet10();
            this.returneddBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.returneddTableAdapter = new SZB.SZBDataSet10TableAdapters.returneddTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iRBookBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sZBDataSet12 = new SZB.SZBDataSet12();
            this.button3 = new System.Windows.Forms.Button();
            this.iRBookTableAdapter = new SZB.SZBDataSet11TableAdapters.IRBookTableAdapter();
            this.iRBookTableAdapter1 = new SZB.SZBDataSet12TableAdapters.IRBookTableAdapter();
            this.stidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdphoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booknameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookissuedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdphoneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stdemailDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booknameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookissuedateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookreturndateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iRBookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.issuedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.returneddBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iRBookBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet12)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stidDataGridViewTextBoxColumn,
            this.stdnameDataGridViewTextBoxColumn,
            this.stdphoneDataGridViewTextBoxColumn,
            this.stdemailDataGridViewTextBoxColumn,
            this.booknameDataGridViewTextBoxColumn,
            this.bookissuedateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.iRBookBindingSource;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(12, 105);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(181)))), ((int)(((byte)(241)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(181)))), ((int)(((byte)(241)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(656, 119);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.ReadOnlyChanged += new System.EventHandler(this.dataGridView1_ReadOnlyChanged);
            // 
            // iRBookBindingSource
            // 
            this.iRBookBindingSource.DataMember = "IRBook";
            this.iRBookBindingSource.DataSource = this.sZBDataSet11;
            // 
            // sZBDataSet11
            // 
            this.sZBDataSet11.DataSetName = "SZBDataSet11";
            this.sZBDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // issuedBindingSource
            // 
            this.issuedBindingSource.DataMember = "issued";
            this.issuedBindingSource.DataSource = this.sZBDataSet6;
            // 
            // sZBDataSet6
            // 
            this.sZBDataSet6.DataSetName = "SZBDataSet6";
            this.sZBDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // issuedTableAdapter
            // 
            this.issuedTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label3.Location = new System.Drawing.Point(253, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 21);
            this.label3.TabIndex = 9;
            this.label3.Text = "Wypożyczone książki";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label1.Location = new System.Drawing.Point(272, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 21);
            this.label1.TabIndex = 10;
            this.label1.Text = "Oddane książki";
            // 
            // sZBDataSet7
            // 
            this.sZBDataSet7.DataSetName = "SZBDataSet7";
            this.sZBDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returnedBindingSource
            // 
            this.returnedBindingSource.DataMember = "returned";
            this.returnedBindingSource.DataSource = this.sZBDataSet7;
            // 
            // returnedTableAdapter
            // 
            this.returnedTableAdapter.ClearBeforeFill = true;
            // 
            // sZBDataSet8
            // 
            this.sZBDataSet8.DataSetName = "SZBDataSet8";
            this.sZBDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returnedBindingSource1
            // 
            this.returnedBindingSource1.DataMember = "returned";
            this.returnedBindingSource1.DataSource = this.sZBDataSet8;
            // 
            // returnedTableAdapter1
            // 
            this.returnedTableAdapter1.ClearBeforeFill = true;
            // 
            // sZBDataSet9
            // 
            this.sZBDataSet9.DataSetName = "SZBDataSet9";
            this.sZBDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returnedBindingSource2
            // 
            this.returnedBindingSource2.DataMember = "returned";
            this.returnedBindingSource2.DataSource = this.sZBDataSet9;
            // 
            // returnedTableAdapter2
            // 
            this.returnedTableAdapter2.ClearBeforeFill = true;
            // 
            // sZBDataSet10
            // 
            this.sZBDataSet10.DataSetName = "SZBDataSet10";
            this.sZBDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // returneddBindingSource
            // 
            this.returneddBindingSource.DataMember = "returnedd";
            this.returneddBindingSource.DataSource = this.sZBDataSet10;
            // 
            // returneddTableAdapter
            // 
            this.returneddTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HotTrack;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stidDataGridViewTextBoxColumn1,
            this.stdnameDataGridViewTextBoxColumn1,
            this.stdphoneDataGridViewTextBoxColumn1,
            this.stdemailDataGridViewTextBoxColumn1,
            this.booknameDataGridViewTextBoxColumn1,
            this.bookissuedateDataGridViewTextBoxColumn1,
            this.bookreturndateDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.iRBookBindingSource1;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.Black;
            this.dataGridView2.Location = new System.Drawing.Point(12, 294);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(181)))), ((int)(((byte)(241)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(181)))), ((int)(((byte)(241)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.RowHeadersWidth = 51;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.Size = new System.Drawing.Size(656, 212);
            this.dataGridView2.TabIndex = 63;
            this.dataGridView2.ReadOnlyChanged += new System.EventHandler(this.dataGridView1_ReadOnlyChanged);
            // 
            // iRBookBindingSource1
            // 
            this.iRBookBindingSource1.DataMember = "IRBook";
            this.iRBookBindingSource1.DataSource = this.sZBDataSet12;
            // 
            // sZBDataSet12
            // 
            this.sZBDataSet12.DataSetName = "SZBDataSet12";
            this.sZBDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button3.Location = new System.Drawing.Point(628, -3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 40);
            this.button3.TabIndex = 64;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // iRBookTableAdapter
            // 
            this.iRBookTableAdapter.ClearBeforeFill = true;
            // 
            // iRBookTableAdapter1
            // 
            this.iRBookTableAdapter1.ClearBeforeFill = true;
            // 
            // stidDataGridViewTextBoxColumn
            // 
            this.stidDataGridViewTextBoxColumn.DataPropertyName = "st_id";
            this.stidDataGridViewTextBoxColumn.HeaderText = "Id studenta";
            this.stidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.stidDataGridViewTextBoxColumn.Name = "stidDataGridViewTextBoxColumn";
            this.stidDataGridViewTextBoxColumn.ReadOnly = true;
            this.stidDataGridViewTextBoxColumn.Width = 125;
            // 
            // stdnameDataGridViewTextBoxColumn
            // 
            this.stdnameDataGridViewTextBoxColumn.DataPropertyName = "std_name";
            this.stdnameDataGridViewTextBoxColumn.HeaderText = "Imie i nazwisko";
            this.stdnameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.stdnameDataGridViewTextBoxColumn.Name = "stdnameDataGridViewTextBoxColumn";
            this.stdnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.stdnameDataGridViewTextBoxColumn.Width = 125;
            // 
            // stdphoneDataGridViewTextBoxColumn
            // 
            this.stdphoneDataGridViewTextBoxColumn.DataPropertyName = "std_phone";
            this.stdphoneDataGridViewTextBoxColumn.HeaderText = "Numer telefonu";
            this.stdphoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.stdphoneDataGridViewTextBoxColumn.Name = "stdphoneDataGridViewTextBoxColumn";
            this.stdphoneDataGridViewTextBoxColumn.ReadOnly = true;
            this.stdphoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // stdemailDataGridViewTextBoxColumn
            // 
            this.stdemailDataGridViewTextBoxColumn.DataPropertyName = "std_email";
            this.stdemailDataGridViewTextBoxColumn.HeaderText = "Adres email";
            this.stdemailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.stdemailDataGridViewTextBoxColumn.Name = "stdemailDataGridViewTextBoxColumn";
            this.stdemailDataGridViewTextBoxColumn.ReadOnly = true;
            this.stdemailDataGridViewTextBoxColumn.Width = 125;
            // 
            // booknameDataGridViewTextBoxColumn
            // 
            this.booknameDataGridViewTextBoxColumn.DataPropertyName = "book_name";
            this.booknameDataGridViewTextBoxColumn.HeaderText = "Tytuł";
            this.booknameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.booknameDataGridViewTextBoxColumn.Name = "booknameDataGridViewTextBoxColumn";
            this.booknameDataGridViewTextBoxColumn.ReadOnly = true;
            this.booknameDataGridViewTextBoxColumn.Width = 125;
            // 
            // bookissuedateDataGridViewTextBoxColumn
            // 
            this.bookissuedateDataGridViewTextBoxColumn.DataPropertyName = "book_issue_date";
            this.bookissuedateDataGridViewTextBoxColumn.HeaderText = "Data wypożyczenia";
            this.bookissuedateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bookissuedateDataGridViewTextBoxColumn.Name = "bookissuedateDataGridViewTextBoxColumn";
            this.bookissuedateDataGridViewTextBoxColumn.ReadOnly = true;
            this.bookissuedateDataGridViewTextBoxColumn.Width = 125;
            // 
            // stidDataGridViewTextBoxColumn1
            // 
            this.stidDataGridViewTextBoxColumn1.DataPropertyName = "st_id";
            this.stidDataGridViewTextBoxColumn1.HeaderText = "Id studenta";
            this.stidDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.stidDataGridViewTextBoxColumn1.Name = "stidDataGridViewTextBoxColumn1";
            this.stidDataGridViewTextBoxColumn1.ReadOnly = true;
            this.stidDataGridViewTextBoxColumn1.Width = 125;
            // 
            // stdnameDataGridViewTextBoxColumn1
            // 
            this.stdnameDataGridViewTextBoxColumn1.DataPropertyName = "std_name";
            this.stdnameDataGridViewTextBoxColumn1.HeaderText = "Imie i nazwisko";
            this.stdnameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.stdnameDataGridViewTextBoxColumn1.Name = "stdnameDataGridViewTextBoxColumn1";
            this.stdnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.stdnameDataGridViewTextBoxColumn1.Width = 125;
            // 
            // stdphoneDataGridViewTextBoxColumn1
            // 
            this.stdphoneDataGridViewTextBoxColumn1.DataPropertyName = "std_phone";
            this.stdphoneDataGridViewTextBoxColumn1.HeaderText = "Numer telefonu";
            this.stdphoneDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.stdphoneDataGridViewTextBoxColumn1.Name = "stdphoneDataGridViewTextBoxColumn1";
            this.stdphoneDataGridViewTextBoxColumn1.ReadOnly = true;
            this.stdphoneDataGridViewTextBoxColumn1.Width = 125;
            // 
            // stdemailDataGridViewTextBoxColumn1
            // 
            this.stdemailDataGridViewTextBoxColumn1.DataPropertyName = "std_email";
            this.stdemailDataGridViewTextBoxColumn1.HeaderText = "Adres email";
            this.stdemailDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.stdemailDataGridViewTextBoxColumn1.Name = "stdemailDataGridViewTextBoxColumn1";
            this.stdemailDataGridViewTextBoxColumn1.ReadOnly = true;
            this.stdemailDataGridViewTextBoxColumn1.Width = 125;
            // 
            // booknameDataGridViewTextBoxColumn1
            // 
            this.booknameDataGridViewTextBoxColumn1.DataPropertyName = "book_name";
            this.booknameDataGridViewTextBoxColumn1.HeaderText = "Tytuł";
            this.booknameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.booknameDataGridViewTextBoxColumn1.Name = "booknameDataGridViewTextBoxColumn1";
            this.booknameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.booknameDataGridViewTextBoxColumn1.Width = 125;
            // 
            // bookissuedateDataGridViewTextBoxColumn1
            // 
            this.bookissuedateDataGridViewTextBoxColumn1.DataPropertyName = "book_issue_date";
            this.bookissuedateDataGridViewTextBoxColumn1.HeaderText = "Data wypożyczenia";
            this.bookissuedateDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.bookissuedateDataGridViewTextBoxColumn1.Name = "bookissuedateDataGridViewTextBoxColumn1";
            this.bookissuedateDataGridViewTextBoxColumn1.ReadOnly = true;
            this.bookissuedateDataGridViewTextBoxColumn1.Width = 125;
            // 
            // bookreturndateDataGridViewTextBoxColumn
            // 
            this.bookreturndateDataGridViewTextBoxColumn.DataPropertyName = "book_return_date";
            this.bookreturndateDataGridViewTextBoxColumn.HeaderText = "Data oddania";
            this.bookreturndateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bookreturndateDataGridViewTextBoxColumn.Name = "bookreturndateDataGridViewTextBoxColumn";
            this.bookreturndateDataGridViewTextBoxColumn.ReadOnly = true;
            this.bookreturndateDataGridViewTextBoxColumn.Width = 125;
            // 
            // AllBooksDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 518);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "AllBooksDetails";
            this.Text = "AllBooksDetails";
            this.Load += new System.EventHandler(this.CompleteBookDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iRBookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.issuedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returnedBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.returneddBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iRBookBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sZBDataSet12)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private SZBDataSet6 sZBDataSet6;
        private System.Windows.Forms.BindingSource issuedBindingSource;
        private SZBDataSet6TableAdapters.issuedTableAdapter issuedTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private SZBDataSet7 sZBDataSet7;
        private System.Windows.Forms.BindingSource returnedBindingSource;
        private SZBDataSet7TableAdapters.returnedTableAdapter returnedTableAdapter;
        private SZBDataSet8 sZBDataSet8;
        private System.Windows.Forms.BindingSource returnedBindingSource1;
        private SZBDataSet8TableAdapters.returnedTableAdapter returnedTableAdapter1;
        private SZBDataSet9 sZBDataSet9;
        private System.Windows.Forms.BindingSource returnedBindingSource2;
        private SZBDataSet9TableAdapters.returnedTableAdapter returnedTableAdapter2;
        private SZBDataSet10 sZBDataSet10;
        private System.Windows.Forms.BindingSource returneddBindingSource;
        private SZBDataSet10TableAdapters.returneddTableAdapter returneddTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button3;
        private SZBDataSet11 sZBDataSet11;
        private System.Windows.Forms.BindingSource iRBookBindingSource;
        private SZBDataSet11TableAdapters.IRBookTableAdapter iRBookTableAdapter;
        private SZBDataSet12 sZBDataSet12;
        private System.Windows.Forms.BindingSource iRBookBindingSource1;
        private SZBDataSet12TableAdapters.IRBookTableAdapter iRBookTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdphoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookissuedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdphoneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stdemailDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookissuedateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookreturndateDataGridViewTextBoxColumn;
    }
}